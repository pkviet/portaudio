<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Source | Git | Assembla</title>
<meta name="description" content="">
<meta name="application-name" content=“Assembla”/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="favicon/mstile-144x144.png" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets0.assembla.com/assets/favicon/apple-touch-icon-57x57-1e493c03db1fef5459f6a60c4ae9963b.png" sizes="57x57" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets1.assembla.com/assets/favicon/apple-touch-icon-114x114-630895c99f0517f31d9f8dc093f8c459.png" sizes="114x114" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets1.assembla.com/assets/favicon/apple-touch-icon-72x72-8656bddb70017b32843b9f997f5a4c53.png" sizes="72x72" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets1.assembla.com/assets/favicon/apple-touch-icon-144x144-596c018ab630a6353ad63bd40153da4f.png" sizes="144x144" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets0.assembla.com/assets/favicon/apple-touch-icon-120x120-c03e3a236a08b2b269c9ae03bdc562d2.png" sizes="120x120" />
<link rel="apple-touch-icon-precomposed" type="image/x-icon" href="https://assets1.assembla.com/assets/favicon/apple-touch-icon-152x152-220a2de261695986b48809cd268ecd2f.png" sizes="152x152" />
<link rel="icon" type="image/png" href="https://assets2.assembla.com/assets/favicon/favicon-32x32-b59ed5d1648b680d32c2a76988fd05e3.png" sizes="32x32" />
<link rel="icon" type="image/png" href="https://assets0.assembla.com/assets/favicon/favicon-16x16-81878073a82f7a8cb2c803bc920fc98f.png" sizes="16x16" />
<script>
    dataLayer = [];
  </script>

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-M82252');</script>

<script src="https://assets3.assembla.com/assets/_/app/tracking-86de2947f3c02e12a1964989c1293ccb.js"></script>
<script type="text/javascript">
    window.breakout_tracking = {
      tracking_url: "https://tracking.assembla.com",
      breakout_uid_cookie_name: "dui",
      temporary_uid_cookie_name: "_breakout_uid"
    };

    window.breakoutTracker = new BreakoutTracking(window.breakout_tracking.temporary_uid_cookie_name);
  </script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","errorBeacon":"bam.nr-data.net","licenseKey":"9dfe439095","applicationID":"8763","transactionName":"Il9dRhNbCVtVQhgXQgBTVkFOVwpTVW9VFl0WQ1ZATkcNWEc=","queueTime":1,"applicationTime":63,"agent":"","atts":"GhJGEFtPR0JDVUU7WwUSCRADUwNGBEF2VXUTAmJYKFUEVnhbDhNoQ01O"}</script>
<script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={xpid:"XA4HUkVbDwUD"};window.NREUM||(NREUM={}),__nr_require=function(t,n,e){function r(e){if(!n[e]){var o=n[e]={exports:{}};t[e][0].call(o.exports,function(n){var o=t[e][1][n];return r(o||n)},o,o.exports)}return n[e].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<e.length;o++)r(e[o]);return r}({1:[function(t,n,e){function r(t){try{s.console&&console.log(t)}catch(n){}}var o,i=t("ee"),a=t(15),s={};try{o=localStorage.getItem("__nr_flags").split(","),console&&"function"==typeof console.log&&(s.console=!0,o.indexOf("dev")!==-1&&(s.dev=!0),o.indexOf("nr_dev")!==-1&&(s.nrDev=!0))}catch(c){}s.nrDev&&i.on("internal-error",function(t){r(t.stack)}),s.dev&&i.on("fn-err",function(t,n,e){r(e.stack)}),s.dev&&(r("NR AGENT IN DEVELOPMENT MODE"),r("flags: "+a(s,function(t,n){return t}).join(", ")))},{}],2:[function(t,n,e){function r(t,n,e,r,s){try{p?p-=1:o(s||new UncaughtException(t,n,e),!0)}catch(f){try{i("ierr",[f,c.now(),!0])}catch(d){}}return"function"==typeof u&&u.apply(this,a(arguments))}function UncaughtException(t,n,e){this.message=t||"Uncaught error with no additional information",this.sourceURL=n,this.line=e}function o(t,n){var e=n?null:c.now();i("err",[t,e])}var i=t("handle"),a=t(16),s=t("ee"),c=t("loader"),f=t("gos"),u=window.onerror,d=!1,l="nr@seenError",p=0;c.features.err=!0,t(1),window.onerror=r;try{throw new Error}catch(h){"stack"in h&&(t(8),t(7),"addEventListener"in window&&t(5),c.xhrWrappable&&t(9),d=!0)}s.on("fn-start",function(t,n,e){d&&(p+=1)}),s.on("fn-err",function(t,n,e){d&&!e[l]&&(f(e,l,function(){return!0}),this.thrown=!0,o(e))}),s.on("fn-end",function(){d&&!this.thrown&&p>0&&(p-=1)}),s.on("internal-error",function(t){i("ierr",[t,c.now(),!0])})},{}],3:[function(t,n,e){t("loader").features.ins=!0},{}],4:[function(t,n,e){function r(t){}if(window.performance&&window.performance.timing&&window.performance.getEntriesByType){var o=t("ee"),i=t("handle"),a=t(8),s=t(7),c="learResourceTimings",f="addEventListener",u="resourcetimingbufferfull",d="bstResource",l="resource",p="-start",h="-end",m="fn"+p,w="fn"+h,v="bstTimer",y="pushState",g=t("loader");g.features.stn=!0,t(6);var b=NREUM.o.EV;o.on(m,function(t,n){var e=t[0];e instanceof b&&(this.bstStart=g.now())}),o.on(w,function(t,n){var e=t[0];e instanceof b&&i("bst",[e,n,this.bstStart,g.now()])}),a.on(m,function(t,n,e){this.bstStart=g.now(),this.bstType=e}),a.on(w,function(t,n){i(v,[n,this.bstStart,g.now(),this.bstType])}),s.on(m,function(){this.bstStart=g.now()}),s.on(w,function(t,n){i(v,[n,this.bstStart,g.now(),"requestAnimationFrame"])}),o.on(y+p,function(t){this.time=g.now(),this.startPath=location.pathname+location.hash}),o.on(y+h,function(t){i("bstHist",[location.pathname+location.hash,this.startPath,this.time])}),f in window.performance&&(window.performance["c"+c]?window.performance[f](u,function(t){i(d,[window.performance.getEntriesByType(l)]),window.performance["c"+c]()},!1):window.performance[f]("webkit"+u,function(t){i(d,[window.performance.getEntriesByType(l)]),window.performance["webkitC"+c]()},!1)),document[f]("scroll",r,{passive:!0}),document[f]("keypress",r,!1),document[f]("click",r,!1)}},{}],5:[function(t,n,e){function r(t){for(var n=t;n&&!n.hasOwnProperty(u);)n=Object.getPrototypeOf(n);n&&o(n)}function o(t){s.inPlace(t,[u,d],"-",i)}function i(t,n){return t[1]}var a=t("ee").get("events"),s=t(18)(a,!0),c=t("gos"),f=XMLHttpRequest,u="addEventListener",d="removeEventListener";n.exports=a,"getPrototypeOf"in Object?(r(document),r(window),r(f.prototype)):f.prototype.hasOwnProperty(u)&&(o(window),o(f.prototype)),a.on(u+"-start",function(t,n){var e=t[1],r=c(e,"nr@wrapped",function(){function t(){if("function"==typeof e.handleEvent)return e.handleEvent.apply(e,arguments)}var n={object:t,"function":e}[typeof e];return n?s(n,"fn-",null,n.name||"anonymous"):e});this.wrapped=t[1]=r}),a.on(d+"-start",function(t){t[1]=this.wrapped||t[1]})},{}],6:[function(t,n,e){var r=t("ee").get("history"),o=t(18)(r);n.exports=r,o.inPlace(window.history,["pushState","replaceState"],"-")},{}],7:[function(t,n,e){var r=t("ee").get("raf"),o=t(18)(r),i="equestAnimationFrame";n.exports=r,o.inPlace(window,["r"+i,"mozR"+i,"webkitR"+i,"msR"+i],"raf-"),r.on("raf-start",function(t){t[0]=o(t[0],"fn-")})},{}],8:[function(t,n,e){function r(t,n,e){t[0]=a(t[0],"fn-",null,e)}function o(t,n,e){this.method=e,this.timerDuration=isNaN(t[1])?0:+t[1],t[0]=a(t[0],"fn-",this,e)}var i=t("ee").get("timer"),a=t(18)(i),s="setTimeout",c="setInterval",f="clearTimeout",u="-start",d="-";n.exports=i,a.inPlace(window,[s,"setImmediate"],s+d),a.inPlace(window,[c],c+d),a.inPlace(window,[f,"clearImmediate"],f+d),i.on(c+u,r),i.on(s+u,o)},{}],9:[function(t,n,e){function r(t,n){d.inPlace(n,["onreadystatechange"],"fn-",s)}function o(){var t=this,n=u.context(t);t.readyState>3&&!n.resolved&&(n.resolved=!0,u.emit("xhr-resolved",[],t)),d.inPlace(t,y,"fn-",s)}function i(t){g.push(t),h&&(x?x.then(a):w?w(a):(E=-E,O.data=E))}function a(){for(var t=0;t<g.length;t++)r([],g[t]);g.length&&(g=[])}function s(t,n){return n}function c(t,n){for(var e in t)n[e]=t[e];return n}t(5);var f=t("ee"),u=f.get("xhr"),d=t(18)(u),l=NREUM.o,p=l.XHR,h=l.MO,m=l.PR,w=l.SI,v="readystatechange",y=["onload","onerror","onabort","onloadstart","onloadend","onprogress","ontimeout"],g=[];n.exports=u;var b=window.XMLHttpRequest=function(t){var n=new p(t);try{u.emit("new-xhr",[n],n),n.addEventListener(v,o,!1)}catch(e){try{u.emit("internal-error",[e])}catch(r){}}return n};if(c(p,b),b.prototype=p.prototype,d.inPlace(b.prototype,["open","send"],"-xhr-",s),u.on("send-xhr-start",function(t,n){r(t,n),i(n)}),u.on("open-xhr-start",r),h){var x=m&&m.resolve();if(!w&&!m){var E=1,O=document.createTextNode(E);new h(a).observe(O,{characterData:!0})}}else f.on("fn-end",function(t){t[0]&&t[0].type===v||a()})},{}],10:[function(t,n,e){function r(t){var n=this.params,e=this.metrics;if(!this.ended){this.ended=!0;for(var r=0;r<d;r++)t.removeEventListener(u[r],this.listener,!1);if(!n.aborted){if(e.duration=a.now()-this.startTime,4===t.readyState){n.status=t.status;var i=o(t,this.lastSize);if(i&&(e.rxSize=i),this.sameOrigin){var c=t.getResponseHeader("X-NewRelic-App-Data");c&&(n.cat=c.split(", ").pop())}}else n.status=0;e.cbTime=this.cbTime,f.emit("xhr-done",[t],t),s("xhr",[n,e,this.startTime])}}}function o(t,n){var e=t.responseType;if("json"===e&&null!==n)return n;var r="arraybuffer"===e||"blob"===e||"json"===e?t.response:t.responseText;return h(r)}function i(t,n){var e=c(n),r=t.params;r.host=e.hostname+":"+e.port,r.pathname=e.pathname,t.sameOrigin=e.sameOrigin}var a=t("loader");if(a.xhrWrappable){var s=t("handle"),c=t(11),f=t("ee"),u=["load","error","abort","timeout"],d=u.length,l=t("id"),p=t(14),h=t(13),m=window.XMLHttpRequest;a.features.xhr=!0,t(9),f.on("new-xhr",function(t){var n=this;n.totalCbs=0,n.called=0,n.cbTime=0,n.end=r,n.ended=!1,n.xhrGuids={},n.lastSize=null,p&&(p>34||p<10)||window.opera||t.addEventListener("progress",function(t){n.lastSize=t.loaded},!1)}),f.on("open-xhr-start",function(t){this.params={method:t[0]},i(this,t[1]),this.metrics={}}),f.on("open-xhr-end",function(t,n){"loader_config"in NREUM&&"xpid"in NREUM.loader_config&&this.sameOrigin&&n.setRequestHeader("X-NewRelic-ID",NREUM.loader_config.xpid)}),f.on("send-xhr-start",function(t,n){var e=this.metrics,r=t[0],o=this;if(e&&r){var i=h(r);i&&(e.txSize=i)}this.startTime=a.now(),this.listener=function(t){try{"abort"===t.type&&(o.params.aborted=!0),("load"!==t.type||o.called===o.totalCbs&&(o.onloadCalled||"function"!=typeof n.onload))&&o.end(n)}catch(e){try{f.emit("internal-error",[e])}catch(r){}}};for(var s=0;s<d;s++)n.addEventListener(u[s],this.listener,!1)}),f.on("xhr-cb-time",function(t,n,e){this.cbTime+=t,n?this.onloadCalled=!0:this.called+=1,this.called!==this.totalCbs||!this.onloadCalled&&"function"==typeof e.onload||this.end(e)}),f.on("xhr-load-added",function(t,n){var e=""+l(t)+!!n;this.xhrGuids&&!this.xhrGuids[e]&&(this.xhrGuids[e]=!0,this.totalCbs+=1)}),f.on("xhr-load-removed",function(t,n){var e=""+l(t)+!!n;this.xhrGuids&&this.xhrGuids[e]&&(delete this.xhrGuids[e],this.totalCbs-=1)}),f.on("addEventListener-end",function(t,n){n instanceof m&&"load"===t[0]&&f.emit("xhr-load-added",[t[1],t[2]],n)}),f.on("removeEventListener-end",function(t,n){n instanceof m&&"load"===t[0]&&f.emit("xhr-load-removed",[t[1],t[2]],n)}),f.on("fn-start",function(t,n,e){n instanceof m&&("onload"===e&&(this.onload=!0),("load"===(t[0]&&t[0].type)||this.onload)&&(this.xhrCbStart=a.now()))}),f.on("fn-end",function(t,n){this.xhrCbStart&&f.emit("xhr-cb-time",[a.now()-this.xhrCbStart,this.onload,n],n)})}},{}],11:[function(t,n,e){n.exports=function(t){var n=document.createElement("a"),e=window.location,r={};n.href=t,r.port=n.port;var o=n.href.split("://");!r.port&&o[1]&&(r.port=o[1].split("/")[0].split("@").pop().split(":")[1]),r.port&&"0"!==r.port||(r.port="https"===o[0]?"443":"80"),r.hostname=n.hostname||e.hostname,r.pathname=n.pathname,r.protocol=o[0],"/"!==r.pathname.charAt(0)&&(r.pathname="/"+r.pathname);var i=!n.protocol||":"===n.protocol||n.protocol===e.protocol,a=n.hostname===document.domain&&n.port===e.port;return r.sameOrigin=i&&(!n.hostname||a),r}},{}],12:[function(t,n,e){function r(){}function o(t,n,e){return function(){return i(t,[f.now()].concat(s(arguments)),n?null:this,e),n?void 0:this}}var i=t("handle"),a=t(15),s=t(16),c=t("ee").get("tracer"),f=t("loader"),u=NREUM;"undefined"==typeof window.newrelic&&(newrelic=u);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",p=l+"ixn-";a(d,function(t,n){u[n]=o(l+n,!0,"api")}),u.addPageAction=o(l+"addPageAction",!0),u.setCurrentRouteName=o(l+"routeName",!0),n.exports=newrelic,u.interaction=function(){return(new r).get()};var h=r.prototype={createTracer:function(t,n){var e={},r=this,o="function"==typeof n;return i(p+"tracer",[f.now(),t,e],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],e),o)try{return n.apply(this,arguments)}catch(t){throw c.emit("fn-err",[arguments,this,t],e),t}finally{c.emit("fn-end",[f.now()],e)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(t,n){h[n]=o(p+n)}),newrelic.noticeError=function(t){"string"==typeof t&&(t=new Error(t)),i("err",[t,f.now()])}},{}],13:[function(t,n,e){n.exports=function(t){if("string"==typeof t&&t.length)return t.length;if("object"==typeof t){if("undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer&&t.byteLength)return t.byteLength;if("undefined"!=typeof Blob&&t instanceof Blob&&t.size)return t.size;if(!("undefined"!=typeof FormData&&t instanceof FormData))try{return JSON.stringify(t).length}catch(n){return}}}},{}],14:[function(t,n,e){var r=0,o=navigator.userAgent.match(/Firefox[\/\s](\d+\.\d+)/);o&&(r=+o[1]),n.exports=r},{}],15:[function(t,n,e){function r(t,n){var e=[],r="",i=0;for(r in t)o.call(t,r)&&(e[i]=n(r,t[r]),i+=1);return e}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],16:[function(t,n,e){function r(t,n,e){n||(n=0),"undefined"==typeof e&&(e=t?t.length:0);for(var r=-1,o=e-n||0,i=Array(o<0?0:o);++r<o;)i[r]=t[n+r];return i}n.exports=r},{}],17:[function(t,n,e){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],18:[function(t,n,e){function r(t){return!(t&&t instanceof Function&&t.apply&&!t[a])}var o=t("ee"),i=t(16),a="nr@original",s=Object.prototype.hasOwnProperty,c=!1;n.exports=function(t,n){function e(t,n,e,o){function nrWrapper(){var r,a,s,c;try{a=this,r=i(arguments),s="function"==typeof e?e(r,a):e||{}}catch(f){l([f,"",[r,a,o],s])}u(n+"start",[r,a,o],s);try{return c=t.apply(a,r)}catch(d){throw u(n+"err",[r,a,d],s),d}finally{u(n+"end",[r,a,c],s)}}return r(t)?t:(n||(n=""),nrWrapper[a]=t,d(t,nrWrapper),nrWrapper)}function f(t,n,o,i){o||(o="");var a,s,c,f="-"===o.charAt(0);for(c=0;c<n.length;c++)s=n[c],a=t[s],r(a)||(t[s]=e(a,f?s+o:o,i,s))}function u(e,r,o){if(!c||n){var i=c;c=!0;try{t.emit(e,r,o,n)}catch(a){l([a,e,r,o])}c=i}}function d(t,n){if(Object.defineProperty&&Object.keys)try{var e=Object.keys(t);return e.forEach(function(e){Object.defineProperty(n,e,{get:function(){return t[e]},set:function(n){return t[e]=n,n}})}),n}catch(r){l([r])}for(var o in t)s.call(t,o)&&(n[o]=t[o]);return n}function l(n){try{t.emit("internal-error",n)}catch(e){}}return t||(t=o),e.inPlace=f,e.flag=a,e}},{}],ee:[function(t,n,e){function r(){}function o(t){function n(t){return t&&t instanceof r?t:t?c(t,s,i):i()}function e(e,r,o,i){if(!l.aborted||i){t&&t(e,r,o);for(var a=n(o),s=h(e),c=s.length,f=0;f<c;f++)s[f].apply(a,r);var d=u[y[e]];return d&&d.push([g,e,r,a]),a}}function p(t,n){v[t]=h(t).concat(n)}function h(t){return v[t]||[]}function m(t){return d[t]=d[t]||o(e)}function w(t,n){f(t,function(t,e){n=n||"feature",y[e]=n,n in u||(u[n]=[])})}var v={},y={},g={on:p,emit:e,get:m,listeners:h,context:n,buffer:w,abort:a,aborted:!1};return g}function i(){return new r}function a(){(u.api||u.feature)&&(l.aborted=!0,u=l.backlog={})}var s="nr@context",c=t("gos"),f=t(15),u={},d={},l=n.exports=o();l.backlog=u},{}],gos:[function(t,n,e){function r(t,n,e){if(o.call(t,n))return t[n];var r=e();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return t[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(t,n,e){function r(t,n,e,r){o.buffer([t],r),o.emit(t,n,e)}var o=t("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(t,n,e){function r(t){var n=typeof t;return!t||"object"!==n&&"function"!==n?-1:t===window?0:a(t,i,function(){return o++})}var o=1,i="nr@id",a=t("gos");n.exports=r},{}],loader:[function(t,n,e){function r(){if(!x++){var t=b.info=NREUM.info,n=l.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(t&&t.licenseKey&&t.applicationID&&n))return u.abort();f(y,function(n,e){t[n]||(t[n]=e)}),c("mark",["onload",a()+b.offset],null,"api");var e=l.createElement("script");e.src="https://"+t.agent,n.parentNode.insertBefore(e,n)}}function o(){"complete"===l.readyState&&i()}function i(){c("mark",["domContent",a()+b.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(s=Math.max((new Date).getTime(),s))-b.offset}var s=(new Date).getTime(),c=t("handle"),f=t(15),u=t("ee"),d=window,l=d.document,p="addEventListener",h="attachEvent",m=d.XMLHttpRequest,w=m&&m.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:m,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},g=m&&w&&w[p]&&!/CriOS/.test(navigator.userAgent),b=n.exports={offset:s,now:a,origin:v,features:{},xhrWrappable:g};t(12),l[p]?(l[p]("DOMContentLoaded",i,!1),d[p]("load",r,!1)):(l[h]("onreadystatechange",o),d[h]("onload",r)),c("mark",["firstbyte",s],null,"api");var x=0,E=t(17)},{}]},{},["loader",2,10,4,3]);</script>
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<!--[if IE]>
        <link rel="stylesheet" media="all" href="https://assets0.assembla.com/stylesheets/v4/ve_ie.css" />
      <![endif]-->
<link rel="stylesheet" media="all" href="https://assets1.assembla.com/assets/v4/v4-2d734fddf718c622353e86272aa4ec62.css" />
<link rel="stylesheet" media="all" href="https://assets3.assembla.com/assets/v4/v4-global-05e200ff05a7f9938865c475995e02cc.css" />
<link rel="stylesheet" media="all" href="https://assets3.assembla.com/assets/sections/code_browser/code_browser-40ea7410bdd51991d1e99048f72faa30.css" />
<meta name="csrf-param" content="authenticity_token" />
<meta name="csrf-token" content="VTAYcaoDvYiFu6Ymui1kXjnSgKbtbEkk+G2fR77uMqsGdqxOnz3nSx4IpkPCxnMsJdWzOlugCRl9mLsW0po8mw==" />
<script type="text/javascript">
  if (!Breakout) { var Breakout = {}; }
      Breakout.space_wiki_name = "portaudio";
      Breakout.space_id = "arhHGeUuSr4k70eJe4gwI3";
    Breakout.space_new_record = false;
    Breakout.hasEditPermission = true;
    Breakout.hasAllPermission = false;
    Breakout.hasViewPermission = true;
    Breakout.hasTicketTool = true;
    Breakout.hasDocumentTool = false;
    Breakout.controller_name = "spaces/code_browser"
    Breakout.action_name = "show"
  Breakout.notifications_enabled = 'false';
    Breakout.enableTrackers = true;
  Breakout.alertsPopup = true;
    Breakout.dropboxKey = 'gssgpyfjwg7czeb';

  Breakout.rootUrl = "https://www.assembla.com/";
  Breakout.clickTrackingUrl = "/tracking/click/:name";

  Breakout.newPlansTableEnabled = true;
  Breakout.instantUploadEnabled = true;

  Breakout.promoCodesEnabled = false;

  Breakout.ticketDetailsPage = false;
  Breakout.captchaField = "g-recaptcha-response";
  Breakout.captchaChallengeField = "";
  Breakout.noBilling = false;


</script>
</head>
<body class="layoutV4 new-profile-page">
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-M82252" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!--[if lt IE 9]><p class="chromeframe">Your web browser is very old. Please <a href="http://browsehappy.com/">upgrade to a modern web browser</a> to experience this website.</p><![endif]-->
<div class="navigation-wrapper">
<div class="navigation nav-dropdowns" data-mobile-ready="true">
<div>
<div class="nav-right float-right">
<div class='nav-right-wrapper'>
<a class="btn-new-grayLink" href="/login">Login</a>
<a class="btn-new-primary" href="https://www.assembla.com/pricing">Sign Up</a>
</div>
</div>
<div class="nav-left float-left ">
<div class="nav-left-wrap clearfix">
<div class="nav-content nav-home">
<span class="nav-item hidden-sd">
<a href="/">
<img alt="Home" title="Assembla Home" src="https://assets0.assembla.com/assets/assembla-logo-shield-695cca917ad9fefd3670ec8c8a369146.png" />
</a> </span>
</div>
<div class="js-nav-content nav-content nav-spaces">
<span class="nav-separator hidden-sd"></span>
<span class="nav-item with-dropdown" data-popup-header="spaces-main-list-popup" data-actions="click mouseenter" data-popup-xsd-disabled="true" data-mobile-sidebar="spaces-main-list-sidebar">
<span aria-hidden="true" data-icon="&#xe648;" class="iconSize--m nav-more ico-hamburger visible-sd"></span>
<span class="hidden-s"><a href="https://www.assembla.com/">My Home</a></span>
<a title="PortAudio" class="visible-s" href="https://www.assembla.com/spaces/show/portaudio">PortAudio</a>
</span>
</div>
<div class=" nav-content nav-spaces hidden-s">
<span class="nav-separator hidden-s"></span>
<span class="nav-item readonly"><span class="nav-text">PortAudio</span></span>
</div>

<div class="nav-content nav-tools">
<span class="nav-separator"></span>
<span class="nav-item readonly"><span class="iconSize--s hidden-sd nav-more" aria-hidden="true" data-icon="&#xe685;"></span><a class="nav-text" title="Git" href="/spaces/portaudio/git/source">Git</a><div id="nav-tools-triangle" class="submenu-triangle"></div></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Wiki" href="/spaces/portaudio/wiki">Wiki</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Tickets" href="/spaces/portaudio/tickets">Tickets</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Stream" href="/spaces/portaudio/stream">Stream</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Team" href="/spaces/portaudio/team">Team</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Support" href="/spaces/portaudio/support/tickets">Support</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="SVN" href="/spaces/portaudio/subversion/source">SVN</a></span><span class="nav-item lesser-nav-item hidden-n"><a class="quick-access-tool" title="Messages" href="/spaces/portaudio/messages">Messages</a></span>

<script src="https://assets0.assembla.com/assets/new_navigation_quick_access-df06c935aa33f02528aeb39c0a489653.js"></script>
<div class="js-nav-content">
<span class="nav-item nav-icon-item with-dropdown hidden-sd" data-popup-header="sections-popup" data-actions="click mouseenter" data-popup-xsd-disabled="true">
<span aria-hidden="true" data-icon="&#xe6ad;" class="iconSize--s nav-more"><span aria-hidden="true" data-icon="&#xe602;" class="iconSize--s nav-more"></span></span>
<a class="hidden-n" href="#">...</a>
</span>
<div class="nav-icon-dropdown " data-popup-box="sections-popup">
<div class="triangle" style="margin-left: 18px;"></div>
<div class="nav-dropdown-list tmp-track-sections-popup">
<ul>
<li class="nav-icon-dropdown-item active">
<a class="icon-colour-b-14" title="Git" href="/spaces/portaudio/git/source"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe685;"></span><span>Git</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-4" title="Wiki" href="/spaces/portaudio/wiki"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe680;"></span><span>Wiki</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-2" title="Tickets" href="/spaces/portaudio/tickets"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe677;"></span><span>Tickets</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-6" title="Stream" href="/spaces/portaudio/stream"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe63f;"></span><span>Stream</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-7" title="Team" href="/spaces/portaudio/team"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe65f;"></span><span>Team</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-11" title="Support" href="/spaces/portaudio/support/tickets"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe66f;"></span><span>Support</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-14" title="SVN" href="/spaces/portaudio/subversion/source"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe6af;"></span><span>SVN</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-3" title="Messages" href="/spaces/portaudio/messages"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe647;"></span><span>Messages</span></a>
</li>
</ul>
</div> 
</div> 
</div>
</div>
</div>
</div>
</div>
</div>
<div id="spaces-main-list-sidebar" class="hamburger-menu visible-sd" data-mobile-sidebar="spaces-main-list-sidebar">
<div class="menu-sidebar">
<ul class="nav-icon-dropdown">
<li class="nav-icon-dropdown-item">
<a class="icon-colour-a-1" href="/">
<span aria-hidden="true" data-icon="&#xe66c;" class="iconSize--s nav-more"></span><span>Go Home</span>
</a> </li>
</ul>
<div class="nav-header">Space Tools</div>
<ul class="nav-icon-dropdown">
<li class="nav-icon-dropdown-item active">
<a class="icon-colour-b-14" title="Git" href="/spaces/portaudio/git/source"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe685;"></span><span>Git</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-4" title="Wiki" href="/spaces/portaudio/wiki"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe680;"></span><span>Wiki</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-2" title="Tickets" href="/spaces/portaudio/tickets"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe677;"></span><span>Tickets</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-6" title="Stream" href="/spaces/portaudio/stream"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe63f;"></span><span>Stream</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-7" title="Team" href="/spaces/portaudio/team"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe65f;"></span><span>Team</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-11" title="Support" href="/spaces/portaudio/support/tickets"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe66f;"></span><span>Support</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-14" title="SVN" href="/spaces/portaudio/subversion/source"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe6af;"></span><span>SVN</span></a>
</li>
<li class="nav-icon-dropdown-item ">
<a class="icon-colour-b-3" title="Messages" href="/spaces/portaudio/messages"><span class="iconSize--m" aria-hidden="true" data-icon="&#xe647;"></span><span>Messages</span></a>
</li>
</ul>
</div>
<div class="layer"></div>
</div>
</div>
<div id="header-w">
<div id="header" class="_">
<div id="header-links">
<div class="top-space">
<span id="space-role">Free/Public Project</span>
</div>
</div>
<div id="logo">
<div id="space-customlogo" class="space-customlogo-sideborder">
<h1 class="header-w clear-float float-left">
<span>PortAudio</span>
</h1>
</div>
</div>
<div class="cut">&nbsp;</div>
</div>
</div>
<ul class='menu-submenu u-cf'><li source_url><a class="first selected" id="source_url" href="/spaces/portaudio/git/source/master">Source</a></li><li commits_url><a class="" id="commits_url" href="/spaces/portaudio/git/commits/list/master">Commits</a></li><li><a class="" href="/spaces/portaudio/git/compare">Compare</a></li><li><a class="" href="/spaces/portaudio/git/merge_requests">Merge Requests</a></li><li><a class=" last" href="/spaces/portaudio/git/instructions">Instructions</a></li><div id='actions-container' class='float-right' /></ul><div class='cut'></div>
<div class="pageWrap ">
<div class="contentContainer">
<div class="data-pjax-container">
<main class="contentContainer">
<div class="pt-m plr-l mb-l">
<div id="browserToolContainer"></div>
<div id="userProfileContainer"></div>
</div>
</main>
</div>
</div>
<div id="footer-w" class="ta-center mt-xl">
<div id="footer" class="fs-xs lh-s pt-m pb-m bs-dotted ba-0 bt-2 bc-gray--3">
<p>
<a href="/home">Home</a>
/ <a href="http://api-doc.assembla.com/">Developer API</a>
/ <a href="/workspaces">Tour</a>
/ <a href="/user/edit/account">Get a Project</a>
&nbsp; - &nbsp; Solutions for <a href="/workspaces">Bug &amp; Issue Tracking</a>, <a href="/workspaces">Collaboration Tools</a>, <a href="http://offers.assembla.com/free-subversion-hosting">Free Subversion Hosting</a>, <a href="http://offers.assembla.com/free-git-hosting">Free GIT Hosting</a>
</p>
<p id="copyr-contact" class="fs-xxs c-gray--2">
Portaudio is powered by Assembla.
</p>
</div>
</div>
</div>
<script id="real-time-settings" type="application/json">{"scheme":"https","channels":{"ticket":"$spacearhHGeUuSr4k70eJe4gwI3-ticket:ticket_number","tickets":"$spacearhHGeUuSr4k70eJe4gwI3-tickets","space_tool":"$spacearhHGeUuSr4k70eJe4gwI3-tool$bv_YN-c8Sr5Rtcdmr6QqzO","notification_center":"$userbgfq4qA1Gr2QjIaaaHk9wZ"},"connection":{"url":"rt.assembla.com:443","user":"bgfq4qA1Gr2QjIaaaHk9wZ","timestamp":"1525905677","token":"09b77a68ae2fa424546f8ef4bedbe0c83907d2f5870a130187c30864b048a5da","info":"{\"id\":\"bgfq4qA1Gr2QjIaaaHk9wZ\",\"name\":\"Anonymous\",\"image_url\":\"https://assets3.assembla.com/assets/avatars/big/9-03f32a6bba1d981860ec86f26fb04208.png\",\"profile_url\":\"/user/popup_profile/Anonymous\"}","transports":["websocket"],"authEndpoint":"/api/realtime_auth"},"comment_bot":{"id":"comment-bot","name":"Assembla Bot","profile_url":""},"version":"1.0.0","is_enabled":true,"debug":false}</script>
<script src="https://assets2.assembla.com/assets/packages/base-5df8ff0b7b89d3a85f1f686857eab52a.js"></script>
<script src="https://assets2.assembla.com/assets/packages/new_global-29dd8bb12a855a685e201327ae0497b7.js"></script>
<script src="https://assets0.assembla.com/assets/packages/new_notification_center-4672caeb21ed206bc2fc40d09912bdcc.js"></script>
<script src="https://assets2.assembla.com/assets/packages/upload-812cdb5e03882e9b70a1f71821d41672.js"></script>
<script src="https://assets0.assembla.com/assets/packages/code_browser-30268c36f1707f923d686dfe99663209.js"></script>
<script type="application/json" id="new-space-manager">{"urls":{"check_availability":"/spaces/check_url_availability","create_space":"/user/create_new_space","create_tool":"/spaces/:id/create_new_repo"},"images":{"logo":"https://assets0.assembla.com/assets/assembla-logo-shield-695cca917ad9fefd3670ec8c8a369146.png","home_logo":"https://assets1.assembla.com/assets/assembla-logo-home-ce43e3c42aa931298e112b7475e3e857.png"},"user":{"name":"Anonymous"},"accounts":[{"id":"bgfq4qA1Gr2QjIaaaHk9wZ","name":"Anonymous (me)"}],"portfolios":[],"portfolio_id":"","has_spaces":true,"tool_ids":{"subversion":"12","git":"128","perforce":"24"},"autostart":false,"allow_perforce":false}</script>
<div id="newSpaceContainer"></div>
<script type="application/json" id="plus-button-integrations-manager">{"integrations":{"github":{"enabled":false,"settings":[],"authorized":false,"authorize_url":"/user/authorizations/github/authorize?return_to=https%3A%2F%2Fwww.assembla.com%2Fspaces%2Fportaudio%2Fgit%2Fsource%2Fmaster%2Fsrc%2Fhostapi%2Fasio%2Fiasiothiscallresolver.cpp%3Frd%3D1","urls":{"repos":"/ext_integrations/github/repos","pull_requests":"/ext_integrations/github/pull_requests","create_repo":"/spaces/portaudio/github_repo_tool","create_pull_request":"/ext_integrations/github/pull_requests/portaudio/tickets/:ticket_number/pull_requests","delete_pull_request":"/ext_integrations/github/pull_requests/portaudio/tickets/:ticket_number/pull_requests/:id"},"button_image_url":"https://assets2.assembla.com/assets/logos/logo_github_mono-99fd8d969fa117efdfb46221647fe878.png","help_image_url":"https://assets3.assembla.com/assets/github-integration/git-help-335f2bea664268e0faa81fc334fd7e3e.png","learn_more_url":"https://blog.assembla.com/real-time-github-com-integration","get_ticket_github_pull_requests_url":"/spaces/portaudio/tickets/:ticket_number/details/github_pull_requests.json","reference":"re #portaudio/:ticket_number","selected_repo_id":null},"slack":{"enabled":false,"show_additional_fields":true,"slack_code_activity_allowed":null,"slack_code_activity_enabled":null,"settings":[],"authorized":false,"authorize_url":"/user/authorizations/slack/authorize?return_to=https%3A%2F%2Fwww.assembla.com%2Fspaces%2Fportaudio%2Fgit%2Fsource%2Fmaster%2Fsrc%2Fhostapi%2Fasio%2Fiasiothiscallresolver.cpp%3Frd%3D1&space=arhHGeUuSr4k70eJe4gwI3","urls":{"users":"/ext_integrations/slack/users","channels":"/ext_integrations/slack/channels","remind":"/ext_integrations/slack/remind","message":"/ext_integrations/slack/message","code_activity_subscribe":"/ext_integrations/slack/code_activity_subscribe","code_activity_unsubscribe":"/ext_integrations/slack/code_activity_unsubscribe"}},"zapier":{"enabled":true}},"urls":{"basic_auth":"/user/authorizations/:id/authorize_basic","enable_integration":"/spaces/portaudio/integrations/:id/enable","disable_integration":"/spaces/portaudio/integrations/:id/disable","remove_authorization":"/user/authorizations/:id"},"show_github_popup":false}</script>
<div id="files-tool-modals">
<div id="file-actions-container"></div>
<div id="folder-actions-container"></div>
<div id="copy-modal"></div>
<div id="move-modal"></div>
<div id="versions-modal"></div>
<div id="file-edit-modal"></div>
<div id="details-modal"></div>
<div id="share-modal"></div>
<div id="modal-screen" class="modal-screen is-active" style="display:none;"></div>
</div>
<script type="data/container" id="repo-tool-options" data-documents-url="/spaces/portaudio/git/source" data-current-location="master/src/hostapi/asio/iasiothiscallresolver.cpp" data-current-type="" data-type="code_browser" data-load-refs="true" data-is-svn="false" data-is-git="true" data-is-perforce="false" data-can-create-mr="false" data-can-create-fork="false" data-create-mr-path="/spaces/portaudio/git/compare?show_merge_request_form=true" data-create-fork-path="/code/portaudio/git/forks/new" data-has-view-permission="true" data-uploading-file-enable="true"></script>
<script type="data/container" id="code-browser-manager" data-breadcrumbs-url-pattern="/spaces/portaudio/git/source/breadcrumbs/:path" data-document-url-pattern="/spaces/portaudio/git/source/:path" data-commits-url-pattern="/spaces/portaudio/git/commits/list/:path" data-locked-nodes-url-pattern="/spaces/portaudio/git/source/locked_nodes/:path" data-props-url-pattern="/spaces/portaudio/git/source/props/:path" data-lock-url-pattern="/spaces/portaudio/git/source/lock" data-unlock-url-pattern="/spaces/portaudio/git/source/unlock" data-create-directory-url-pattern="/spaces/portaudio/git/source/create_directory" data-create-file-url-pattern="/spaces/portaudio/git/source/create_file" data-update-file-url-pattern="/spaces/portaudio/git/source/update_file" data-upload-file-url-pattern="/spaces/portaudio/git/source/upload_file" data-refs-url="/spaces/portaudio/git/source/refs" data-sub-nodes-url-pattern="/spaces/portaudio/git/source/sub_nodes/:path"></script>
<script type="data/container" id="url-fetcher" data-repo-urls-url="/spaces/portaudio/git/source/urls"></script>
<script type="text/javascript">(function(a){if(window.filepicker){return}var b=a.createElement("script");b.type="text/javascript";b.async=!0;b.src=("https:"===a.location.protocol?"https:":"http:")+"//api.filestackapi.com/filestack.js";var c=a.getElementsByTagName("script")[0];c.parentNode.insertBefore(b,c);var d={};d._queue=[];var e="pick,pickMultiple,pickAndStore,read,write,writeUrl,export,convert,store,storeUrl,remove,stat,setKey,constructWidget,makeDropPane".split(",");var f=function(a,b){return function(){b.push([a,arguments])}};for(var g=0;g<e.length;g++){d[e[g]]=f(e[g],d._queue)}window.filepicker=d})(document);</script>
<script type="application/json" id="instant-upload-setup">{"api_key":"A3d0u130jR6yiTSCk6uBqz","user_id":"bgfq4qA1Gr2QjIaaaHk9wZ","store":{"bucket":"prod-us-west-2-assemblafiles","path":"arhHGeUuSr4k70eJe4gwI3/9f6cf5/"},"attachable":{},"urls":{"instant_upload":"/spaces/portaudio/documents/instant_upload"},"security":{"policy":"eyJleHBpcnkiOjE1MjY1MTA0NzcsImNhbGwiOlsicGljayIsInN0b3JlIl19","signature":"a947364d9a2f56747cc712563bcf7c3ca1ba5f8e294360502a72ba332d223cc1"}}</script>
</body>
</html>
